package com.grooping.oz.service;

public record OzCallResult(
        ResultType type,
        String code,
        String message
) {
    public enum ResultType {
        SUCCESS,
        DEFINITE_FAILURE,
        UNCERTAIN
    }

    public static OzCallResult success() {
        return new OzCallResult(ResultType.SUCCESS, null, null);
    }

    public static OzCallResult failure(String code, String message) {
        return new OzCallResult(ResultType.DEFINITE_FAILURE, code, message);
    }

    public static OzCallResult uncertain(String code, String message) {
        return new OzCallResult(ResultType.UNCERTAIN, code, message);
    }
}

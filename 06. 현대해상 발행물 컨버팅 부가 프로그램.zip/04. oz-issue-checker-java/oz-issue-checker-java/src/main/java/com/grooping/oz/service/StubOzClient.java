package com.grooping.oz.service;

import com.grooping.oz.domain.AsyncProcess;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

/*
 * 개발용 Stub.
 * 운영에서는 실제 OZ Adapter 구현체로 교체한다.
 */
@Component
@Profile("!prod")
public class StubOzClient implements OzClient {

    @Override
    public OzCallResult publish(AsyncProcess process) {
        return OzCallResult.success();
    }
}

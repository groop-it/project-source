package com.grooping.oz.service;

import com.grooping.oz.domain.ProcessStatus;
import com.grooping.oz.mapper.AsyncProcessMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProcessResultService {

    private final AsyncProcessMapper mapper;

    public ProcessResultService(AsyncProcessMapper mapper) {
        this.mapper = mapper;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void stepStart(Long processId, int stepNo) {
        mapper.updateStepStart(processId, stepNo);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void success(Long processId, int stepNo, String step) {
        mapper.updateStepResult(processId, stepNo, ProcessStatus.SUCCESS.name(), null, null);
        mapper.updateProcessResult(processId, ProcessStatus.SUCCESS.name(), step, null, null);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void retryable(Long processId, int stepNo, String step, String code, String message) {
        mapper.updateStepResult(processId, stepNo, ProcessStatus.FAIL.name(), code, message);
        mapper.updateProcessResult(processId, ProcessStatus.RETRYABLE.name(), step, code, message);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void unknown(Long processId, int stepNo, String step, String code, String message) {
        mapper.updateStepResult(processId, stepNo, ProcessStatus.UNKNOWN.name(), code, message);
        mapper.updateProcessResult(processId, ProcessStatus.UNKNOWN.name(), step, code, message);
    }
}

package com.grooping.oz.domain;

public enum StepType {
    OZ,
    EDMS,
    FAX,
    MAIL,
    IMAGE
}

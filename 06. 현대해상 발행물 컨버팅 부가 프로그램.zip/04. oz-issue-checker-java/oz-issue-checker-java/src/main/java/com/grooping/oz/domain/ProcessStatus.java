package com.grooping.oz.domain;

public enum ProcessStatus {
    READY,
    PROCESSING,
    SUCCESS,
    FAIL,
    RETRYABLE,
    UNKNOWN,
    CANCEL
}

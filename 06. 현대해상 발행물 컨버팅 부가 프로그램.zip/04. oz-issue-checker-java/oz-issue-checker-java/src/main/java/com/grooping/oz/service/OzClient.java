package com.grooping.oz.service;

import com.grooping.oz.domain.AsyncProcess;

/*
 * 실제 OZ API/SDK 연동 Adapter.
 * 프로젝트의 OZ 호출 규격이 확정되면 이 Interface 구현체만 교체한다.
 */
public interface OzClient {
    OzCallResult publish(AsyncProcess process);
}

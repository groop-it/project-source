package com.grooping.oz.mapper;

import com.grooping.oz.domain.AsyncProcess;
import com.grooping.oz.domain.AsyncProcessStep;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AsyncProcessMapper {

    AsyncProcess findByRequestId(@Param("requestId") String requestId);

    AsyncProcess findByProcessId(@Param("processId") Long processId);

    int insertProcess(AsyncProcess process);

    int insertStep(AsyncProcessStep step);

    Long lockNextProcessId();

    int markProcessing(@Param("processId") Long processId,
                       @Param("processorId") String processorId);

    int updateHeartbeat(@Param("processId") Long processId,
                        @Param("processorId") String processorId);

    int updateProcessResult(@Param("processId") Long processId,
                            @Param("status") String status,
                            @Param("currentStep") String currentStep,
                            @Param("errorCode") String errorCode,
                            @Param("errorMessage") String errorMessage);

    int updateStepStart(@Param("processId") Long processId,
                        @Param("stepNo") int stepNo);

    int updateStepResult(@Param("processId") Long processId,
                         @Param("stepNo") int stepNo,
                         @Param("status") String status,
                         @Param("errorCode") String errorCode,
                         @Param("errorMessage") String errorMessage);

    List<AsyncProcess> findStuckProcesses(@Param("stuckMinutes") int stuckMinutes);

    int markStuckUnknown(@Param("processId") Long processId,
                         @Param("message") String message);
}

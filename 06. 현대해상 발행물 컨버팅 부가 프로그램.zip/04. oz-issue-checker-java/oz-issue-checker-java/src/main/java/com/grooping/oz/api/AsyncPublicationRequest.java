package com.grooping.oz.api;

import jakarta.validation.constraints.NotBlank;

public record AsyncPublicationRequest(
        @NotBlank String requestId,
        @NotBlank String systemId,
        String channelId,
        @NotBlank String formId,
        @NotBlank String payload
) {}

package com.grooping.oz.api;

public record ProcessResponse(
        Long processId,
        String requestId,
        String status,
        String message
) {}

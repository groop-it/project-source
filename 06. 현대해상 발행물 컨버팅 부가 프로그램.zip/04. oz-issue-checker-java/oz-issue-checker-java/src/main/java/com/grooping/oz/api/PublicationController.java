package com.grooping.oz.api;

import com.grooping.oz.domain.AsyncProcess;
import com.grooping.oz.service.AsyncPublicationService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/publications")
public class PublicationController {

    private final AsyncPublicationService service;

    public PublicationController(AsyncPublicationService service) {
        this.service = service;
    }

    @PostMapping("/async")
    public ResponseEntity<ProcessResponse> accept(
            @Valid @RequestBody AsyncPublicationRequest request) {
        return ResponseEntity.accepted().body(service.accept(request));
    }

    @GetMapping("/{requestId}")
    public ResponseEntity<?> status(@PathVariable String requestId) {
        AsyncProcess process = service.getByRequestId(requestId);
        return process == null
                ? ResponseEntity.notFound().build()
                : ResponseEntity.ok(process);
    }
}

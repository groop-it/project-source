package com.grooping.oz.service;

import com.grooping.oz.api.AsyncPublicationRequest;
import com.grooping.oz.api.ProcessResponse;
import com.grooping.oz.domain.AsyncProcess;
import com.grooping.oz.domain.AsyncProcessStep;
import com.grooping.oz.domain.ProcessStatus;
import com.grooping.oz.domain.StepType;
import com.grooping.oz.mapper.AsyncProcessMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AsyncPublicationService {

    private final AsyncProcessMapper mapper;

    public AsyncPublicationService(AsyncProcessMapper mapper) {
        this.mapper = mapper;
    }

    @Transactional
    public ProcessResponse accept(AsyncPublicationRequest request) {
        AsyncProcess existing = mapper.findByRequestId(request.requestId());
        if (existing != null) {
            return new ProcessResponse(
                    existing.getProcessId(),
                    existing.getRequestId(),
                    existing.getStatus().name(),
                    "동일 REQUEST_ID가 이미 존재합니다."
            );
        }

        AsyncProcess process = new AsyncProcess();
        process.setRequestId(request.requestId());
        process.setSystemId(request.systemId());
        process.setChannelId(request.channelId());
        process.setFormId(request.formId());
        process.setProcessType("ASYNC");
        process.setStatus(ProcessStatus.READY);
        process.setCurrentStep(StepType.OZ.name());
        process.setRequestPayload(request.payload());

        mapper.insertProcess(process);

        // 실제 업무별 Step은 설정/정책 테이블로 분리 가능.
        insertStep(process.getProcessId(), 1, StepType.OZ);
        insertStep(process.getProcessId(), 2, StepType.EDMS);
        insertStep(process.getProcessId(), 3, StepType.FAX);
        insertStep(process.getProcessId(), 4, StepType.MAIL);

        // @Transactional이 정상 종료되어 COMMIT된 이후 HTTP 성공 응답이 반환된다.
        return new ProcessResponse(
                process.getProcessId(),
                process.getRequestId(),
                ProcessStatus.READY.name(),
                "비동기 발행 요청이 접수되었습니다."
        );
    }

    public AsyncProcess getByRequestId(String requestId) {
        return mapper.findByRequestId(requestId);
    }

    private void insertStep(Long processId, int stepNo, StepType stepType) {
        AsyncProcessStep step = new AsyncProcessStep();
        step.setProcessId(processId);
        step.setStepNo(stepNo);
        step.setStepType(stepType);
        step.setStatus(ProcessStatus.READY);
        mapper.insertStep(step);
    }
}

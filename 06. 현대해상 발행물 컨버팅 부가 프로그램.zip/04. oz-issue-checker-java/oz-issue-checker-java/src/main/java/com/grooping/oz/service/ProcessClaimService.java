package com.grooping.oz.service;

import com.grooping.oz.domain.AsyncProcess;
import com.grooping.oz.mapper.AsyncProcessMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProcessClaimService {

    private final AsyncProcessMapper mapper;

    public ProcessClaimService(AsyncProcessMapper mapper) {
        this.mapper = mapper;
    }

    /*
     * 중요:
     * Row Lock은 여기서만 짧게 유지한다.
     * OZ 외부 호출은 이 Transaction 밖에서 실행한다.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public AsyncProcess claimNext(String processorId) {
        Long processId = mapper.lockNextProcessId();
        if (processId == null) {
            return null;
        }

        int updated = mapper.markProcessing(processId, processorId);
        if (updated != 1) {
            return null;
        }
        return mapper.findByProcessId(processId);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void heartbeat(Long processId, String processorId) {
        mapper.updateHeartbeat(processId, processorId);
    }
}

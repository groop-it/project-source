package com.grooping.oz.scheduler;

import com.grooping.oz.domain.AsyncProcess;
import com.grooping.oz.mapper.AsyncProcessMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component
public class StuckProcessScheduler {

    private final AsyncProcessMapper mapper;
    private final int stuckMinutes;

    public StuckProcessScheduler(AsyncProcessMapper mapper,
                                 @Value("${oz.async.stuck-minutes:10}") int stuckMinutes) {
        this.mapper = mapper;
        this.stuckMinutes = stuckMinutes;
    }

    @Scheduled(fixedDelayString = "${oz.async.stuck-check-ms:60000}")
    @Transactional
    public void detect() {
        List<AsyncProcess> stuck = mapper.findStuckProcesses(stuckMinutes);
        for (AsyncProcess process : stuck) {
            /*
             * PROCESSING 장기 잔존을 곧바로 RETRYABLE로 돌리지 않는다.
             * OZ 요청이 이미 전달됐을 가능성이 있으므로 UNKNOWN으로 보내
             * 실제 발행 여부 확인 후 SUCCESS/RETRYABLE을 결정한다.
             */
            mapper.markStuckUnknown(
                    process.getProcessId(),
                    "Processor heartbeat expired. OZ 처리 여부 확인 필요."
            );
        }
    }
}

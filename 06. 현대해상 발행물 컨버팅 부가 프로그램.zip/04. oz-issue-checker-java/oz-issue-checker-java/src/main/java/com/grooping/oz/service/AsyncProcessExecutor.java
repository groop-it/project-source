package com.grooping.oz.service;

import com.grooping.oz.domain.AsyncProcess;
import org.springframework.stereotype.Service;

/*
 * 외부 OZ 호출은 DB 선점 Transaction 밖에서 실행한다.
 * UNKNOWN을 별도 상태로 두어 "응답 유실 = 재발행"이 되지 않게 한다.
 */
@Service
public class AsyncProcessExecutor {

    private final OzClient ozClient;
    private final ProcessResultService resultService;

    public AsyncProcessExecutor(OzClient ozClient,
                                ProcessResultService resultService) {
        this.ozClient = ozClient;
        this.resultService = resultService;
    }

    public void execute(AsyncProcess process) {
        final int ozStepNo = 1;
        resultService.stepStart(process.getProcessId(), ozStepNo);

        OzCallResult result;
        try {
            result = ozClient.publish(process);
        } catch (java.net.ConnectException e) {
            // 요청 자체가 전달되지 않았다고 명확히 판단 가능한 경우
            resultService.retryable(
                    process.getProcessId(), ozStepNo, "OZ",
                    "OZ_CONNECT_FAIL", e.getMessage()
            );
            return;
        } catch (java.net.SocketTimeoutException e) {
            // 요청 전달 후 결과를 확정할 수 없을 수 있으므로 UNKNOWN
            resultService.unknown(
                    process.getProcessId(), ozStepNo, "OZ",
                    "OZ_TIMEOUT_UNKNOWN", e.getMessage()
            );
            return;
        } catch (Exception e) {
            // 실제 운영에서는 Exception 유형을 더 세분화해야 한다.
            resultService.unknown(
                    process.getProcessId(), ozStepNo, "OZ",
                    "OZ_UNCLASSIFIED", e.getMessage()
            );
            return;
        }

        switch (result.type()) {
            case SUCCESS ->
                    resultService.success(process.getProcessId(), ozStepNo, "OZ");
            case DEFINITE_FAILURE ->
                    resultService.retryable(process.getProcessId(), ozStepNo, "OZ",
                            result.code(), result.message());
            case UNCERTAIN ->
                    resultService.unknown(process.getProcessId(), ozStepNo, "OZ",
                            result.code(), result.message());
        }

        /*
         * EDMS/FAX/MAIL/IMAGE는 실제 연계 규격에 맞춰 Step Processor로 확장한다.
         * 이미 SUCCESS인 Step은 재수행하지 않는 정책을 적용한다.
         */
    }
}

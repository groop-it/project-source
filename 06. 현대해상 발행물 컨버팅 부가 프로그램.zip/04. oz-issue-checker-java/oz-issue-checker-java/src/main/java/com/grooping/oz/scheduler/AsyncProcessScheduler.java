package com.grooping.oz.scheduler;

import com.grooping.oz.domain.AsyncProcess;
import com.grooping.oz.service.AsyncProcessExecutor;
import com.grooping.oz.service.ProcessClaimService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.lang.management.ManagementFactory;
import java.net.InetAddress;

@Component
public class AsyncProcessScheduler {

    private final ProcessClaimService claimService;
    private final AsyncProcessExecutor executor;
    private final int maxPerRun;
    private final String processorId;

    public AsyncProcessScheduler(ProcessClaimService claimService,
                                 AsyncProcessExecutor executor,
                                 @Value("${oz.async.max-per-run:20}") int maxPerRun) {
        this.claimService = claimService;
        this.executor = executor;
        this.maxPerRun = maxPerRun;
        this.processorId = createProcessorId();
    }

    @Scheduled(fixedDelayString = "${oz.async.poll-delay-ms:1000}")
    public void process() {
        for (int i = 0; i < maxPerRun; i++) {
            AsyncProcess target = claimService.claimNext(processorId);
            if (target == null) {
                return;
            }
            executor.execute(target);
        }
    }

    private String createProcessorId() {
        try {
            return InetAddress.getLocalHost().getHostName() + ":" +
                    ManagementFactory.getRuntimeMXBean().getName();
        } catch (Exception e) {
            return "unknown:" + ManagementFactory.getRuntimeMXBean().getName();
        }
    }
}

# OZ Issue Checker - Java Sample

Oracle + Spring Boot + MyBatis + `@Scheduled` 기반의 OZ 비동기 발행 장애 대응 샘플이다.

## 핵심 구현

- 별도 메시지 브로커 없이 Oracle `ASYNC_PROCESS` / `ASYNC_PROCESS_STEP`으로 업무 처리상태 영속화
- REQUEST_ID Unique 제약으로 중복 접수 방지
- `SELECT ... FOR UPDATE SKIP LOCKED` 기반 다중 WAS 처리 대상 선점
- 외부 OZ 호출 전에 선점 Transaction COMMIT
- `SUCCESS / FAIL / RETRYABLE / UNKNOWN` 구분
- Timeout/응답 유실 가능 상황은 UNKNOWN 처리
- 장기 PROCESSING 상태는 자동 재발행하지 않고 UNKNOWN으로 전환
- Spring `@Scheduled` 사용
- WAR + 외부 Tomcat 배포 가능
- Java 21 / Spring Boot / MyBatis / Oracle 기준

## 프로젝트 구조

```text
api
 └─ PublicationController

service
 ├─ AsyncPublicationService
 ├─ ProcessClaimService
 ├─ AsyncProcessExecutor
 ├─ ProcessResultService
 └─ OzClient

scheduler
 ├─ AsyncProcessScheduler
 └─ StuckProcessScheduler

mapper
 └─ AsyncProcessMapper

resources
 ├─ mapper/AsyncProcessMapper.xml
 ├─ schema-oracle.sql
 └─ application.yml
```

## 실행 전

1. `schema-oracle.sql` 실행
2. `application.yml` Oracle 접속정보 변경
3. 실제 OZ API/SDK 규격에 맞는 `OzClient` 운영 구현체 작성
4. 개발용 `StubOzClient`는 prod Profile에서 사용하지 않음
5. 내부 Maven Repository에서 필요한 Dependency를 확보

## API

### 비동기 발행 접수

`POST /api/publications/async`

```json
{
  "requestId": "PUB-20260901-000001",
  "systemId": "HIPORTAL",
  "channelId": "WEB",
  "formId": "FORM-001",
  "payload": "{\"contractNo\":\"123456\"}"
}
```

### 상태 조회

`GET /api/publications/PUB-20260901-000001`

## 중요한 운영 원칙

`SocketTimeoutException` 같은 상황은 실제 OZ 발행 성공 여부가 불명확할 수 있으므로 곧바로 재발행하지 않는다. `UNKNOWN`으로 기록한 뒤 OZ 발행 이력 등을 확인하여 `SUCCESS` 또는 `RETRYABLE`로 확정하는 운영 기능이 추가되어야 한다.

또한 이 샘플의 `OzClient`는 실제 OZ 연동 규격을 알 수 없기 때문에 Interface + Stub까지만 구현되어 있다. 실제 OZ API/SDK 호출부는 프로젝트의 OZ 제품 버전, 호출 프로토콜, 인증, LB 주소, 응답 코드 정의를 반영하여 구현해야 한다.

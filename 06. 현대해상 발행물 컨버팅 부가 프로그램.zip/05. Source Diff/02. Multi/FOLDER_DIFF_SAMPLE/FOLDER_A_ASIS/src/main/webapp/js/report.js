function printReport(contractNo) {
    console.log("RD print start");
    callReport(contractNo);
}

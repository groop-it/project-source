package sample.report;

public class ReportService {
    public void printReport(String contractNo) {
        if (contractNo == null) {
            return;
        }
        String reportName = "contract.mrd";
        callRD(reportName, contractNo);
    }

    private void callRD(String reportName, String contractNo) {
        System.out.println("RD Report : " + reportName);
        System.out.println("Contract No : " + contractNo);
    }
}

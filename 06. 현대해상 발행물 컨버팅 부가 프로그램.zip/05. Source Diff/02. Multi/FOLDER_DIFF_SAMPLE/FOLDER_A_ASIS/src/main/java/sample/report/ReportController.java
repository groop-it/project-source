package sample.report;

public class ReportController {
    private final ReportService service = new ReportService();

    public void print(String contractNo) {
        service.printReport(contractNo);
    }
}

package sample.legacy;

public class RdUtil {
    public static String getRdUrl() {
        return "/rd/report";
    }
}

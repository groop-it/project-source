SOURCE FOLDER DIFF ANALYZER V2 테스트 샘플

Folder A: FOLDER_A_ASIS
Folder B: FOLDER_B_CURRENT

예상 결과
- SAME: ReportController.java
- CHANGED: ReportService.java
- CHANGED: report.xml
- CHANGED: application.properties
- CHANGED: report.js
- DELETED: legacy/RdUtil.java
- ADDED: report/OzReportClient.java

테스트 방법
1. SOURCE_FOLDER_DIFF_ANALYZER_V2.html 실행
2. Folder A에 FOLDER_A_ASIS 선택
3. Folder B에 FOLDER_B_CURRENT 선택
4. '폴더 비교' 클릭
5. 변경 파일을 클릭하여 상세 DIFF 확인

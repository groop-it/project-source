function printReport(contractNo) {
    if (!contractNo) {
        return;
    }
    console.log("OZ print start");
    callReport(contractNo);
}

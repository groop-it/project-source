package sample.report;

public class OzReportClient {
    public void request(String ozrName, String jsonParameter) {
        System.out.println("OZ request : " + ozrName);
    }
}

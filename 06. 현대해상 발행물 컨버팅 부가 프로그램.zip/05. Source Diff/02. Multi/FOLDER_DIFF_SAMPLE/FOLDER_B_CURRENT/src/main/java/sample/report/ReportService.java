package sample.report;

public class ReportService {
    public void printReport(String contractNo) {
        if (contractNo == null || contractNo.isEmpty()) {
            return;
        }
        String reportName = "contract.ozr";
        validateContract(contractNo);
        callOZ(reportName, contractNo);
        savePrintHistory(contractNo);
    }

    private void validateContract(String contractNo) {
        System.out.println("Validate : " + contractNo);
    }

    private void callOZ(String reportName, String contractNo) {
        System.out.println("OZ Report : " + reportName);
        System.out.println("Contract No : " + contractNo);
    }

    private void savePrintHistory(String contractNo) {
        System.out.println("History : " + contractNo);
    }
}

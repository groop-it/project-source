package sample.report;

public class ReportService {

    public void printReport(String contractNo) {

        if (contractNo == null || contractNo.isEmpty()) {
            return;
        }

        System.out.println("Report Start");

        String reportName = "contract.mrd";

        validateContract(contractNo);

        callRD(reportName, contractNo);

        savePrintHistory(contractNo);

        System.out.println("Report Complete");
    }

    private void validateContract(String contractNo) {

        System.out.println("Validate Contract : " + contractNo);
    }

    private void callRD(String reportName, String contractNo) {

        System.out.println("RD Report : " + reportName);
        System.out.println("Contract No : " + contractNo);
    }

    private void savePrintHistory(String contractNo) {

        System.out.println("Save Print History : " + contractNo);
    }
}

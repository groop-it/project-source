package sample.report;

public class ReportService {

    public void printReport(String contractNo) {

        if (contractNo == null) {
            return;
        }

        System.out.println("Report Start");

        String reportName = "contract.mrd";

        callRD(reportName, contractNo);

        System.out.println("Report End");
    }

    private void callRD(String reportName, String contractNo) {

        System.out.println("RD Report : " + reportName);
        System.out.println("Contract No : " + contractNo);
    }
}

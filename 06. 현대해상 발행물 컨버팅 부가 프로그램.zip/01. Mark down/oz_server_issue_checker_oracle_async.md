# OZ Server Issue Checker
## Oracle 기반 동기·비동기 발행 장애 대응 설계


---

## 1. 문서 목적

본 문서는 RD → OZ 전환 및 통합 발행물 시스템 구축 환경에서 다음 문제를 다룬다.

- OZ Server 단일/전체 장애
- 동기 발행 장애
- 비동기 발행 장애
- WAS 이중화 환경의 중복 처리
- OZ 처리 결과가 불명확한 UNKNOWN 상황
- EDMS / FAX / MAIL / 이미지 변환 등 후처리 실패
- Client Emergency 발행
- 서버 복구 후 업무 정상화
- RD/OZ 병행운영
- 성능 및 장애 추적

본 설계의 핵심 원칙은 다음과 같다.

>
> 동기 업무는 HA/Failover 중심으로 처리하고,
> 비동기 업무는 Oracle DB의 영속 Process 상태를 기반으로 처리한다.

---

# 2. 핵심 설계 원칙




다만 비동기 업무는 요청을 메모리에만 보관할 수 없으므로 Oracle DB에 Process 상태를 영속화한다.

```text

Oracle Process DB : 비동기 업무의 상태/복구를 위해 사용
```

DB Process Table은 메시지 브로커 자체를 구축하려는 목적이 아니라 다음을 보장하기 위한 **업무 상태 저장소**이다.

- 접수 여부
- 현재 처리 단계
- 성공/실패 여부
- 재처리 가능 여부
- 중복 처리 방지
- 장애 발생 위치
- 운영자 확인

---

## 2.2 동기와 비동기를 분리한다

```text
                   [ 발행 요청 ]
                        │
                ┌───────┴───────┐
                │               │
              SYNC            ASYNC
                │               │
                ▼               ▼
       Publication Gateway   Oracle Process DB
                │               │
                ▼               ▼
             LB / OZ          Async Processor
                │               │
                ▼               ▼
         즉시 결과 반환       OZ / 후처리
```

동기와 비동기는 장애 복구 정책이 다르므로 동일한 방식으로 처리하지 않는다.

---

# 3. 전체 Target Architecture

```text
                    [ 업무 / 채널 시스템 ]
                              │
                              ▼
                    Publication Gateway
                              │
           ┌──────────────────┼──────────────────┐
           │                  │                  │
      Idempotency        Health Check      Circuit Breaker
           │                  │                  │
           └──────────────────┼──────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │                   │
                  SYNC                ASYNC
                    │                   │
                    ▼                   ▼
             Load Balancer        Oracle Process DB
                │      │                │
                ▼      ▼                ▼
              OZ #1  OZ #2            Async Processor
                │      │                │
                └──┬───┘                ▼
                   │                Load Balancer
                   │                  │      │
                   │                  ▼      ▼
                   │                OZ #1  OZ #2
                   │                  │      │
                   └──────────┬───────┴──────┘
                              │
                              ▼
                     Post Process Layer
                    /       |       |       \
                 EDMS      FAX     MAIL     IMAGE
                              │
                              ▼
                    Result / Statistics
```

---

# 4. 동기(SYNC) 발행 장애 대응

## 4.1 정상 처리

```text
Request
   ↓
Publication Gateway
   ↓
Load Balancer
   ↓
OZ
   ↓
SUCCESS
   ↓
Response
```

---

## 4.2 단일 OZ 장애

```text
OZ #1
  X
  ↓
Health Check FAIL
  ↓
LB 대상 제외
  ↓
OZ #2
  ↓
정상 처리
```

사용자나 업무 Application에서 직접 OZ 서버 상태를 판단하지 않는다.

---

## 4.3 OZ 전체 장애

```text
OZ #1 DOWN
     +
OZ #2 DOWN
     │
     ▼
Circuit Breaker OPEN
     │
     ▼
업무 Criticality 판단
   ┌────────────┴────────────┐
   │                         │
즉시 발행 필수           지연/재시도 가능
   │                         │
   ▼                         ▼
Local Emergency          명시적 FAIL 반환
적합성 검토               사용자 재시도
```

동기 업무에서는 서버가 요청을 임의로 장기 보관하지 않는다.

---

# 5. Client Local Emergency Mode

Client Emergency는 **OZ 전체 장애 시 모든 업무를 대체하는 구조가 아니다.**

다음과 같은 업무에 한해 제한적으로 검토한다.

- 창구 즉시 출력
- 상담 중 고객 서류 발행
- Client Viewer에서 완결 가능한 업무
- 서버 후처리가 필수가 아닌 업무

권장 방향은 고객 데이터를 평상시 Local에 보관하는 것이 아니라 **서식 Resource의 사전 배포 가능성**을 검토하는 것이다.

```text
Client
 └─ Emergency Resource
      ├─ OZR
      ├─ Static Image
      ├─ Font
      ├─ Header/Footer
      └─ Common Resource
```

실제 발행 시에는 현재 Request Data만 사용하고, 임시 데이터가 생성된다면 발행 완료 후 즉시 삭제한다.

### Local Mode 제외 후보

다음은 Client만으로 완결하기 어려울 수 있다.

- 서버사이드 Batch
- 원격지 발행
- EDMS 필수 등록
- FAX/Mail 서버 후처리
- 서버 전용 업무 Logic
- 기관계 Java에서 직접 발행하는 업무

따라서 반드시 PoC를 통해 지원 범위를 확정한다.

---

# 6. 비동기(ASYNC) 발행의 핵심 문제

비동기 업무에서는 다음과 같은 구현을 피한다.

```text
Request
   ↓
@Async / Memory
   ↓
사용자에게 접수 성공
   ↓
WAS DOWN
   ↓
작업 소실
```

사용자가 이미 접수 성공 응답을 받은 상태에서 WAS가 종료되면 작업이 사라질 수 있기 때문이다.

따라서 원칙은 다음과 같다.

```text
Request
   ↓
Oracle PROCESS INSERT
   ↓
COMMIT
   ↓
접수 성공 응답
   ↓
Async Processor Processing
```

**DB COMMIT 이전에는 비동기 접수 성공으로 판단하지 않는다.**

---

# 7. Oracle 기반 Async Process Control

## 7.1 기본 구조

```text
ASYNC Request
     ↓
ASYNC_PROCESS INSERT
     ↓
ASYNC_PROCESS_STEP INSERT
     ↓
COMMIT
     ↓
접수 완료
     ↓
Async Processor
     ↓
Process 선점
     ↓
OZ
     ↓
Post Process
     ↓
SUCCESS / FAIL / UNKNOWN
```

---

## 7.2 ASYNC_PROCESS 예시

```text
PROCESS_ID
REQUEST_ID
SYSTEM_ID
CHANNEL_ID
FORM_ID
PROCESS_TYPE
STATUS
CURRENT_STEP
RETRY_COUNT
CREATED_AT
STARTED_AT
UPDATED_AT
COMPLETED_AT
ERROR_CODE
ERROR_MESSAGE
```

권장 상태:

```text
READY
PROCESSING
SUCCESS
FAIL
RETRYABLE
UNKNOWN
CANCEL
```

---

## 7.3 ASYNC_PROCESS_STEP 예시

```text
PROCESS_ID
STEP_NO
STEP_TYPE
STATUS
STARTED_AT
COMPLETED_AT
ERROR_CODE
ERROR_MESSAGE
```

예:

```text
PROCESS-10001

STEP 1  OZ        SUCCESS
STEP 2  EDMS      SUCCESS
STEP 3  FAX       FAIL
STEP 4  MAIL      READY
```

이 경우 재처리는 OZ부터 다시 시작하는 것이 아니라 정책에 따라 실패한 FAX 단계부터 재개할 수 있다.

---

# 8. Oracle 다중 Async Processor 제어

운영 WAS/Async Processor가 여러 대라면 동일 Process을 동시에 가져가지 않아야 한다.

개념적으로 Oracle의 Row Lock을 이용한다.

```sql
SELECT PROCESS_ID
FROM ASYNC_PROCESS
WHERE STATUS IN ('READY', 'RETRYABLE')
ORDER BY CREATED_AT
FOR UPDATE SKIP LOCKED;
```

Async Processor #1이 특정 Process Row를 잠근 상태에서는 Async Processor #2가 해당 Row를 기다리지 않고 건너뛰어 다른 작업을 가져갈 수 있도록 설계한다.

> 실제 SQL은 사용 중인 Oracle 버전, Batch Fetch 방식, 처리 건수 제한 방식에 맞추어 별도 검증한다.

처리 흐름:

```text
Async Processor #1 ──→ PROCESS-001 Lock
Async Processor #2 ──→ PROCESS-001 Skip
              PROCESS-002 Lock
```

선점 후:

```text
READY
  ↓
PROCESSING
```

으로 상태를 변경한다.

Lock Transaction을 외부 OZ 호출 전체 시간 동안 길게 유지하는 방식은 피하고, **짧은 선점 Transaction + 상태 기반 소유권** 방식으로 설계하는 것을 권장한다.

예:

```text
1. Row Lock
2. STATUS = PROCESSING
3. PROCESSOR_ID 저장
4. STARTED_AT 저장
5. COMMIT
6. 외부 OZ 호출
```

---

# 9. Async Processor 장애 대응

문제가 되는 상황:

```text
PROCESS = PROCESSING
       ↓
Async Processor DOWN
       ↓
영원히 PROCESSING?
```

이를 막기 위해 다음 항목을 둔다.

```text
PROCESSOR_ID
STARTED_AT
HEARTBEAT_AT
```

운영 정책 예:

```text
PROCESSING
+
HEARTBEAT 장시간 미갱신
        ↓
STUCK 후보
        ↓
업무 상태 확인
        ↓
RETRYABLE 또는 운영자 확인
```

단, OZ 요청을 이미 전달한 뒤 Async Processor가 죽었다면 단순 RETRY하면 안 된다.

이 경우 `UNKNOWN` 판단이 필요하다.

---

# 10. UNKNOWN 상태가 가장 중요하다

발행 업무에서는 다음 상황이 가능하다.

```text
Async Processor
   │
   │ OZ 발행 요청
   ▼
OZ
   │
   ├─ 실제 발행 성공
   │
   └─ 응답 전달
          X Network Timeout

Async Processor 결과 = ?
```

Async Processor는 실패처럼 보지만 실제 발행은 완료되었을 수 있다.

따라서:

```text
FAIL ≠ UNKNOWN
```

으로 구분한다.

### FAIL

명확하게 처리되지 않았음을 확인할 수 있는 경우.

```text
Connection Refused
OZ Server Down before request
명시적 오류 응답
```

정책에 따라 Secondary 전환 또는 재처리 가능.

### UNKNOWN

요청 전달 이후 처리 결과를 확정할 수 없는 경우.

```text
Read Timeout
Connection Lost after send
Async Processor Crash after request
Response Lost
```

이 경우 자동 재발행을 금지하는 것이 기본 원칙이다.

```text
UNKNOWN
   ↓
발행 이력 / 결과 확인
   ↓
┌──────────────┴──────────────┐
│                             │
발행 확인                    미발행 확인
│                             │
SUCCESS                    RETRYABLE
```

---

# 11. Idempotency / 중복 발행 방지

모든 발행 요청에 고유 `REQUEST_ID`를 부여한다.

```text
REQUEST_ID
SYSTEM_ID
FORM_ID
BUSINESS_KEY
```

예:

```text
PUB-20260901-000001
```

처리 전:

```text
REQUEST_ID 조회
      │
      ├─ SUCCESS 존재 → 중복 발행 차단/기존 결과 반환
      │
      ├─ PROCESSING → 진행 중 반환
      │
      ├─ UNKNOWN → 상태 확인 필요
      │
      └─ 없음 → 신규 처리
```

특히 Retry와 Failover에서 중복 출력이 발생하지 않도록 한다.

---

# 12. Retry 정책

Retry는 모든 오류에 적용하지 않는다.

## Retry 가능 후보

```text
CONNECT_FAIL
SERVER_UNAVAILABLE
일시적 NETWORK 오류
명확한 미처리 응답
```

## 자동 Retry 금지 후보

```text
UNKNOWN
발행 성공 여부 확인 불가
후처리 일부 성공
중복 가능성이 높은 업무
```

따라서 Retry 판단은 다음과 같이 한다.

```text
Error
 ↓
재처리 안전성 판단
 ├─ SAFE   → RETRYABLE
 └─ UNSAFE → UNKNOWN / 운영자 확인
```

---

# 13. Post Process 설계

OZ 발행 이후 업무가 다음과 같이 이어질 수 있다.

```text
OZ
 ↓
EDMS
 ↓
FAX
 ↓
MAIL
 ↓
IMAGE
```

이를 하나의 거대한 Transaction으로 묶지 않는다.

Process Step으로 상태를 관리한다.

```text
OZ       SUCCESS
EDMS     SUCCESS
FAX      FAIL
MAIL     READY
```

재처리 시 이미 성공한 OZ를 무조건 다시 호출하지 않도록 한다.

---

# 14. Oracle Transaction 범위

외부 시스템 호출을 포함하여 DB Transaction을 지나치게 길게 유지하지 않는다.

피해야 할 구조:

```text
SELECT FOR UPDATE
       ↓
Row Lock 유지
       ↓
OZ 30초 호출
       ↓
EDMS 20초 호출
       ↓
COMMIT
```

권장:

```text
[ Transaction A ]

Process 선점
 ↓
PROCESSING 변경
 ↓
COMMIT


[ External Processing ]

OZ 호출
 ↓
결과 확보


[ Transaction B ]

SUCCESS / FAIL / UNKNOWN 저장
 ↓
COMMIT
```

이를 통해 Lock 장기 점유를 줄인다.

---

# 15. Circuit Breaker

Circuit Breaker는 장애 단계가 아니라 Publication Gateway/Async Processor의 OZ 호출을 보호하는 공통 기능이다.

```text
          ┌──── Circuit Breaker ────┐
          │                         │
Gateway/Async Processor → LB → OZ #1 / OZ #2
          │                         │
          └─────────────────────────┘
```

예:

```text
연속 장애 임계치 도달
      ↓
OPEN
      ↓
불필요한 OZ 호출 차단
      ↓
일정 시간 후
      ↓
HALF_OPEN
      ↓
Probe 성공
      ↓
CLOSED
```

이를 통해 OZ 장애가 WAS Thread 고갈로 확산되는 것을 방지한다.

---

# 16. Health Check

단순 Port Check만으로 정상 여부를 판단하지 않는다.

단계별 확인 후보:

```text
L1 TCP
L2 HTTP
L3 OZ Application
L4 Test Rendering
L5 NAS Resource
L6 Dependency
```

상태:

```text
UP
DEGRADED
DOWN
UNKNOWN
```

LB Health Check와 Application Health Check의 역할을 구분한다.

---

# 17. RD/OZ 병행운영

기존 RD Flow는 보존하면서 시스템/서식별 전환 Flag로 OZ를 선택한다.

```text
발행 요청
   ↓
Routing Policy
   │
   ├─ RD → RD Adapter
   │
   └─ OZ → OZ Adapter
```

관리 예:

```text
SYSTEM_ID
CHANNEL_ID
FORM_ID
ENGINE_TYPE
USE_YN
START_DTM
ROLLBACK_YN
```

빅뱅 전환보다 단계별 전환과 Rollback 가능성을 우선한다.

---

# 18. 성능 개선

성능 문제를 단순히 OZ Rendering 문제로 가정하지 않는다.

```text
TOTAL
 ├─ BUSINESS
 ├─ DB
 ├─ XML → JSON
 ├─ NETWORK
 ├─ OZ REQUEST
 ├─ OZ RENDERING
 ├─ NAS
 └─ POST PROCESS
```

측정 지표:

- AVG
- MIN/MAX
- P50
- P95
- P99
- Timeout Count
- Failover Count
- UNKNOWN Count
- Retry Count
- Post Process Time

개선 후보:

- OZR/Static Resource Cache
- OZ 9.x 제공 기능 비교
- NAS 접근 최적화
- Parameter 축소
- XML → JSON 변환 비용 확인
- Connection Pool
- HTTP Keep-Alive
- DB SQL/Index
- 후처리 단계 분리
- 불필요 동기 처리 제거
- Network Latency 분석

성능 목표는 반드시 AS-IS Baseline을 먼저 측정한 후 설정한다.

---

# 19. 보안

특히 Local Emergency에서 다음을 검토한다.

- 개인정보 Local 영구 저장 금지
- Temp File 삭제
- Client Resource 접근권한
- OZR 위변조 방지
- 로그 개인정보 Masking
- 내부/외부망 Cross 통신 제한
- API 인증/인가
- TLS
- Server Access Control
- 장애 로그의 민감정보 포함 여부

---

# 20. Monitoring

필수 추적값:

```text
REQUEST_ID
PROCESS_ID
SYSTEM_ID
FORM_ID
ENGINE_TYPE
PROCESS_TYPE (SYNC/ASYNC)
OZ_SERVER
PROCESSOR_ID
CURRENT_STEP
STATUS
START_TIME
END_TIME
ELAPSED_TIME
RETRY_COUNT
FAILOVER_YN
ERROR_CODE
ERROR_MESSAGE
```

Dashboard 후보:

```text
OZ #1 STATUS
OZ #2 STATUS

SYNC SUCCESS / FAIL
ASYNC READY
ASYNC PROCESSING
ASYNC RETRYABLE
ASYNC UNKNOWN
ASYNC FAIL

AVG RESPONSE
P95 RESPONSE
FAILOVER COUNT
UNKNOWN COUNT
STUCK PROCESS COUNT
POST PROCESS FAIL COUNT
```

---

# 21. 장애별 처리 정책

| 장애 | SYNC | ASYNC |
|---|---|---|
| OZ #1 Down | OZ #2 Failover | OZ #2 Failover |
| OZ #1/#2 Down | Local Emergency 또는 FAIL | Process 상태 유지/RETRYABLE |
| 요청 후 응답 Timeout | UNKNOWN 판단 | UNKNOWN |
| WAS Down | 사용자 재요청 | Oracle Process으로 복구 |
| Async Processor Down | 해당 없음 | Stuck Process 판별 |
| EDMS Down | 업무정책에 따라 FAIL | 해당 Step 실패/재처리 |
| FAX Down | 업무정책에 따라 FAIL | FAX Step 재처리 |
| NAS Down | 발행 제한 | Process 실패/대기 정책 |
| LB Down | HA 설계 필요 | HA 설계 필요 |

---

# 22. 장애 복구 흐름

## 22.1 SYNC

```text
OZ #1 FAIL
   ↓
OZ #2
   ↓
FAIL
   ↓
Criticality
 ├─ Immediate → Local Emergency 검토
 └─ Normal    → FAIL 반환 / 사용자 재시도
```

## 22.2 ASYNC

```text
PROCESS READY
   ↓
Async Processor
   ↓
OZ #1 FAIL
   ↓
OZ #2 FAIL
   ↓
실패 유형 판단
   │
   ├─ 명확한 미처리 → RETRYABLE
   │
   └─ 결과 불명확   → UNKNOWN
```

OZ 복구 후:

```text
RETRYABLE
   ↓
Async Processor 재처리
   ↓
SUCCESS
```

UNKNOWN은 자동 Retry 대상에서 제외하고 결과 확인 절차를 거친다.

---

# 23. Spring 기반 구현 시 고려사항

Spring `@Scheduled`를 Async Processor Trigger로 사용할 수 있다.

```text
@Scheduled
   ↓
처리 대상 Process 조회
   ↓
Oracle Row 선점
   ↓
PROCESSING 변경
   ↓
COMMIT
   ↓
OZ 처리
   ↓
결과 Update
```

단 운영 WAS가 여러 대일 경우 Scheduler 자체를 단일 노드로 제한할 필요는 없으며, Oracle의 Process 선점 정책이 정확하다면 여러 Async Processor가 병렬 처리할 수 있다.

다만 다음은 반드시 검증한다.

- 중복 Process 선점
- Lock 경합
- Async Processor Crash
- PROCESSING Stuck
- Batch 처리량
- DB 부하
- Retry 폭주
- OZ 장애 시 Async Processor 폭주

---

# 24. 테스트 시나리오

## HA

- [ ] OZ #1 종료
- [ ] OZ #2 자동 전환
- [ ] Failover 시간 측정
- [ ] OZ #1 복구
- [ ] LB 재편입

## Total Failure

- [ ] OZ #1/#2 동시 종료
- [ ] SYNC FAIL 처리
- [ ] Client Emergency 가능 업무 검증
- [ ] Local 미지원 업무 검증

## ASYNC

- [ ] Process Insert 후 COMMIT
- [ ] Async Processor 처리
- [ ] Async Processor 2대 동시 처리
- [ ] 동일 Process 중복 선점 방지
- [ ] Async Processor 강제 종료
- [ ] Stuck Process 탐지
- [ ] RETRYABLE 재처리
- [ ] UNKNOWN 자동 재처리 금지

## Duplicate

- [ ] 동일 REQUEST_ID 재요청
- [ ] Timeout 직후 재요청
- [ ] OZ 성공 후 응답 유실
- [ ] 후처리 중 실패
- [ ] 부분 성공 후 재처리

## Performance

- [ ] AS-IS RD Baseline
- [ ] TO-BE OZ Baseline
- [ ] 단건
- [ ] 동시 사용자
- [ ] 대량 Async
- [ ] Failover 중 부하
- [ ] P95/P99 비교

---

# 25. 운영 Runbook

## OZ 장애

```text
1. Health Check 확인
2. LB 상태 확인
3. OZ #1/#2 확인
4. Circuit 상태 확인
5. SYNC 영향 확인
6. ASYNC READY/PROCESSING/UNKNOWN 확인
7. 후처리 영향 확인
8. 복구
9. Health 정상 확인
10. RETRYABLE 순차 재처리
11. UNKNOWN 별도 검증
```

## Async Processor 장애

```text
1. Async Processor 상태 확인
2. PROCESSING Process 조회
3. HEARTBEAT 확인
4. 실제 OZ 처리 여부 확인
5. RETRYABLE / UNKNOWN 결정
6. 재처리
```

---

# 26. 권장 구현 우선순위

## P1 — 반드시 필요

- OZ #1/#2 HA
- LB Health Check
- Publication Gateway
- REQUEST_ID
- SYNC/ASYNC 분리
- Oracle Process Master
- Process Step
- 중복 방지
- UNKNOWN 상태
- Logging

## P2 — 안정화

- Circuit Breaker
- Async Processor 다중화
- Oracle Process 선점
- Stuck Process Recovery
- Retry Policy
- Monitoring
- 운영자 재처리 기능

## P3 — 고도화

- Local Emergency PoC
- 상세 성능 Profiling
- 자동 장애 분석
- Dashboard
- 장애 Pattern 통계
- 전환/성능 데이터 자산화

---

# 27. 최종 권장 구조

```text
                        BUSINESS
                           │
                    Publication API
                           │
              ┌────────────┴────────────┐
              │                         │
            SYNC                      ASYNC
              │                         │
              ▼                         ▼
        Publication GW            Oracle Process DB
              │                         │
      Health / Circuit                  ▼
              │                       Async Processor
              ▼                         │
             LB                         │
          /      \                      │
       OZ #1    OZ #2  ◀────────────────┘
          \      /
             │
             ▼
       Post Processing
       /    |    |    \
    EDMS   FAX  MAIL  IMAGE
```

### SYNC 장애

```text
OZ #1 → OZ #2 → Local Emergency 또는 FAIL
```

### ASYNC 장애

```text
Oracle Process
   ↓
Async Processor
   ↓
OZ #1 → OZ #2
   ↓
SUCCESS / RETRYABLE / UNKNOWN / FAIL
```


---


## 비동기 처리 명칭 및 운영 원칙

비동기 처리는 `ASYNC_PROCESS` / `ASYNC_PROCESS_STEP` 기반의 **Oracle 업무 처리상태 관리**로 정의한다.

```text
ASYNC Request
      ↓
ASYNC_PROCESS 등록
      ↓
COMMIT
      ↓
접수 성공
      ↓
Async Processor
      ↓
OZ 발행
      ↓
ASYNC_PROCESS_STEP 단계별 결과 기록
      ↓
SUCCESS / FAIL / RETRYABLE / UNKNOWN
```

WAS 메모리에만 처리 대상을 보관하지 않으며, Oracle COMMIT이 완료된 이후에만 정상 접수로 판단한다. 처리 중 장애가 발생하면 저장된 상태와 단계 정보를 기준으로 복구 여부를 결정한다.

# 28. 설계 결론

본 시스템에서는 처리대기 도입 여부 자체보다 **동기/비동기 업무 특성에 맞는 장애 복구 모델을 분리하는 것**이 중요하다.

동기 업무는:

```text
HA
→ Failover
→ Local Emergency 또는 명확한 FAIL
```

비동기 업무는:

```text
Oracle Process Persistence
→ Async Processor
→ Step State
→ Retryable 판단
→ Recovery
```

구조를 사용한다.

특히 비동기 처리에서 단순 `@Async` 메모리 실행은 장애 시 작업 소실 위험이 있으므로 사용하지 않으며, **Oracle Commit 완료 후 접수 성공을 반환**하는 것을 기본 원칙으로 한다.

또한 발행 시스템에서는 Timeout이 곧 실패를 의미하지 않는다.

따라서:

```text
SUCCESS
FAIL
RETRYABLE
UNKNOWN
```

을 명확하게 구분하고, `UNKNOWN` 상태는 자동 재발행하지 않는 것이 중복 발행 방지의 핵심이다.

최종적으로 본 설계는 다음 목표를 갖는다.

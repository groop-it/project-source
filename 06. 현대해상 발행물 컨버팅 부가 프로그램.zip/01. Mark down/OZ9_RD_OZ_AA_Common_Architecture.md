# OZ 9 RD→OZ 병행전환 AA 공통 아키텍처 가이드

> **목적**\
> RD와 OZ Report 9를 병행 운영하며 단계적으로 전환하는 프로젝트에서
> AA(Application Architect) 관점의 공통 설계·개발·테스트·운영 기준을
> 정의한다.

## 1. Architecture Goal

``` text
Business Applications
        ↓
Common Report Interface
        ↓
Report Facade
        ↓
Validation / Routing / Trace / Security
        ↓
┌──────────────┬──────────────┐
│              │
RD Adapter    OZ9 Adapter
│              │
RD Server     OZ 9 Server
└──────┬───────┘
       ↓
Post Processing
       ↓
EDMS / FAX / MAIL / IMAGE
```

### 핵심 원칙

1.  업무에서 RD/OZ API를 직접 호출하지 않는다.
2.  업무 모델과 리포팅 솔루션 모델을 분리한다.
3.  RD/OZ 차이는 Adapter 내부에 격리한다.
4.  시스템·채널·서식 단위 단계적 전환을 지원한다.
5.  기존 RD 로직을 최대한 보존한다.
6.  통제된 Rollback을 지원한다.
7.  모든 발행은 Request/Trace ID로 추적한다.
8.  병행운영 기간에 RD/OZ 결과를 검증한다.
9.  OZ Server 자체 Failover는 OZ 솔루션 측 책임과 경계를 확정한다.
10. 향후 다른 Report Engine에도 재사용 가능한 구조로 설계한다.

## 2. AA 공통 Architecture Domain

  \#   Domain                          주요 내용                          우선순위
  ---- ------------------------------- ---------------------------------- ----------
  1    Report Facade / Gateway         단일 공통 발행 Interface           P0
  2    RD/OZ Routing                   시스템·채널·서식별 Engine 선택     P0
  3    Canonical Request Model         솔루션 독립 요청/응답 모델         P0
  4    Report Mapping                  RD 서식 ↔ OZ 서식 Mapping          P0
  5    Parameter Standard              XML→JSON 및 데이터 변환 규칙       P0
  6    Error Model                     공통 Error Code / Exception        P0
  7    Post Processing                 EDMS/FAX/MAIL/Image                P1
  8    Parallel Run / Reconciliation   RD/OZ 결과 비교                    P0
  9    Observability                   Trace/Log/Statistics/Performance   P1
  10   Security                        개인정보/마스킹/권한/파일보안      P1
  11   Performance                     구간별 성능 측정                   P1
  12   Cutover Governance              전환/승인/Rollback/RD 폐기         P0

## 3. Report Facade

업무 프로그램에서는 다음과 같은 단일 공통 인터페이스만 사용한다.

``` java
reportService.publish(request);
```

``` text
업무 A ─┐
업무 B ─┼─→ Report Facade → Report Router ─┬─→ RD Adapter
업무 C ─┤                                 └─→ OZ Adapter
업무 D ─┘
```

OZ API 변경, Report Engine 교체, 공통 보안·로깅·성능 정책을 중앙에서
통제한다.

## 4. Canonical Report Model

업무에서 `RdParameter`, `OzParameter` 같은 제품 종속 객체를 사용하지
않는다.

``` text
ReportRequest
├─ requestId
├─ systemId
├─ channelId
├─ businessId
├─ formId
├─ parameters
├─ outputType
├─ printOption
└─ postProcess
```

``` text
ReportRequest
     ├─→ RD Converter → RD Parameter
     └─→ OZ Converter → OZ Parameter
```

## 5. RD/OZ Routing

권장 최소 Routing Key:

``` text
SYSTEM_ID + CHANNEL_ID + FORM_ID
```

예:

``` text
HIPORTAL + WEB + CONTRACT01 → OZ
CLAIM    + WEB + CONTRACT01 → RD
```

### Routing Table

``` text
REPORT_ROUTING
├─ SYSTEM_ID
├─ CHANNEL_ID
├─ FORM_ID
├─ ENGINE_TYPE
├─ ACTIVE_YN
├─ EFFECTIVE_FROM
├─ ROLLBACK_YN
├─ VERSION
├─ UPDATED_BY
└─ UPDATED_AT
```

Routing 정보가 없거나 조회 실패 시의 기본 정책을 반드시 정의한다.
병행전환 초기에는 기존 RD 유지가 보수적인 기본안이 될 수 있으나 고객사
승인 정책에 따라 확정한다.

## 6. Adapter Pattern

``` java
public interface ReportAdapter {
    ReportResult publish(ReportRequest request);
}
```

``` text
ReportAdapter
├─ RdReportAdapter
└─ Oz9ReportAdapter
```

OZ 고유 API/SDK는 OZ Adapter 내부로 최대한 격리한다.

## 7. Parameter Conversion Standard

``` text
AS-IS
WebSquare → XML → RD

TO-BE
Business → Canonical Parameter → JSON → OZ
```

반드시 정의할 데이터 유형: - String / Number / Boolean - Date /
DateTime - NULL / Empty String - Array / Single Object / Nested Object -
Encoding / Large Text

특히 `NULL`, `""`, `[]`, `{}`, 단건 Object, 다건 Array의 의미 차이를
검증한다.

## 8. Report Mapping Registry

``` text
REPORT_MAPPING
├─ OLD_FORM_ID
├─ NEW_FORM_ID
├─ FORM_NAME
├─ SYSTEM_ID
├─ CHANNEL_ID
├─ VERSION
├─ MIGRATION_STATUS
├─ OWNER
├─ TEST_STATUS
├─ CUTOVER_DATE
└─ ROLLBACK_AVAILABLE
```

서식 ID뿐 아니라 전환·검증 상태까지 중앙 관리한다.

## 9. Parallel Run & Reconciliation

``` text
           동일 Test Data
                │
        ┌───────┴───────┐
        ↓               ↓
       RD               OZ
        ↓               ↓
    Result A         Result B
        └───────┬───────┘
                ↓
         Reconciliation
```

비교 대상: - 페이지 수 - 주요 Field 값 - 금액/날짜 - QR/Image -
Header/Footer - Layout - PDF Size - 필요 시 PDF Hash - Render Time -
후처리 결과

결과 상태:

``` text
MATCH
MISMATCH
EXPECTED_DIFFERENCE
NOT_COMPARABLE
```

PDF Hash는 렌더링 메타데이터 차이로 달라질 수 있으므로 단독 합격
기준으로 사용하지 않는다.

## 10. Cutover / Rollback

``` text
READY
 ↓
DEV_TEST
 ↓
UT
 ↓
IT
 ↓
PARALLEL_RUN
 ↓
BUSINESS_APPROVED
 ↓
OZ_ACTIVE
 ↓
MONITORING
 ↓
RD_RETIRE
```

장애 시:

``` text
OZ_ACTIVE → ISSUE → ROLLBACK_DECISION → RD_ACTIVE
```

서식별 데이터·호출규격·후처리 호환성을 사전 검증해야 한다.

## 11. Error Translation Layer

``` text
OZ Exception
   ↓
OzExceptionTranslator
   ↓
ReportException
   ↓
Common Error Response
```

예:

``` text
REPORT-001 서식 없음
REPORT-002 Parameter 오류
REPORT-003 Engine 호출 실패
REPORT-004 발행 Timeout
REPORT-005 후처리 실패
REPORT-006 Mapping 없음
REPORT-007 Routing 오류
```

## 12. Request ID / Trace ID

예:

``` text
PUB-20260903-000001
```

Browser → Spring → Router → RD/OZ → Post Process → EDMS/FAX 전 구간에서
동일 ID를 유지한다.

``` text
09:11:01 REQUEST
09:11:01 ROUTING=OZ
09:11:02 PARAM_CONVERT
09:11:03 OZ_REQUEST
09:11:11 OZ_RESPONSE
09:11:12 EDMS_REQUEST
09:11:13 COMPLETE
```

## 13. Performance Instrumentation

``` text
TOTAL
├─ ROUTING
├─ PARAM_CONVERT
├─ DB
├─ NETWORK
├─ OZ
├─ RENDER
└─ POST_PROCESS
```

최소 측정값:

``` text
REQUEST_ID
SYSTEM_ID
CHANNEL_ID
FORM_ID
ENGINE
START_TIME
END_TIME
TOTAL_MS
OZ_MS
POST_PROCESS_MS
RESULT
```

통계는 AVG/P50/P95/P99/MAX를 권장한다.

## 14. Post Processing Framework

``` text
Report Publish
   ↓
PostProcessor
   ├─ EDMS
   ├─ FAX
   ├─ MAIL
   └─ IMAGE
```

업무별 하드코딩 대신 `PostProcessor` 인터페이스를 통한 확장 구조를
사용한다.

## 15. Sync / Async Policy

동기:

``` text
사용자 → 발행 → Engine → 결과 → 사용자
```

비동기:

``` text
업무 요청 → 접수 → Server Processing → Engine → 후처리 → 상태반영
```

동기/비동기 선정 기준을 AA 표준으로 정의한다.

## 16. Security Standard

검토 대상: - Input/Parameter Validation - XSS / SQL Injection / Path
Traversal - File/Temporary File Access - Authentication /
Authorization - API Access Control - Sensitive Data - Log Masking

고객·계약 관련 민감정보가 로그나 Exception에 평문으로 남지 않도록 한다.

## 17. Resource Management

대상:

``` text
OZR / Image / Font / Logo / QR / Template / Static Resource
```

관리 속성:

``` text
Version / Path / Owner / Deploy Status / Checksum / Rollback Version
```

## 18. Configuration Externalization

DEV/TEST/STG/PROD 환경별 다음 설정을 외부화한다.

``` text
OZ Endpoint
Timeout
Resource Path
NAS Path
EDMS Endpoint
FAX Endpoint
Log Level
Feature Toggle
```

## 19. Timeout / Retry Policy

공통 Timeout: - Connect Timeout - Read Timeout - Rendering Timeout -
Post Process Timeout - Total Transaction Timeout

Retry 예:

``` text
CONNECT_FAIL      → 재시도 가능 여부 검토
RESPONSE_TIMEOUT  → 결과 불확실 상태
BUSINESS_ERROR    → 자동 Retry 금지
PARAMETER_ERROR   → 자동 Retry 금지
```

최종 정책은 OZ 측 상태조회·중복방지·장애복구 기능과 함께 확정한다.

## 20. Idempotency / Duplicate Protection

후보 Key:

``` text
REQUEST_ID + BUSINESS_KEY + FORM_ID
```

중복 원인: - Double Click - Network Timeout - WAS 재처리 - Browser
재요청 - Async 재실행 - Engine 응답 지연

## 21. Test Framework

``` text
Report Test Framework
├─ Parameter Test
├─ Routing Test
├─ RD Regression Test
├─ OZ Test
├─ Data Compare
├─ PDF/Layout Compare
├─ Performance Test
├─ Error Test
└─ Post Process Test
```

대표 서식을 Pilot으로 먼저 검증한 뒤 대량 전환한다.

## 22. Report Inventory

``` text
FORM_ID
FORM_NAME
SYSTEM
CHANNEL
OWNER
RD_PATH
OZ_PATH
COMPLEXITY
USAGE
MIGRATION_STATUS
UT_STATUS
IT_STATUS
PARALLEL_STATUS
CUTOVER_STATUS
```

## 23. Dependency Registry

``` text
Database / API / Batch / EAI / EDMS / FAX / MAIL / NAS / IMAGE / REMOTE_PRINT
```

서식 변환 성공뿐 아니라 전체 업무 Dependency의 성공 여부를 관리한다.

## 24. Feature Toggle

``` text
SYSTEM + CHANNEL + FORM + DATE
```

``` text
RD ACTIVE → Pilot OZ → Partial OZ → Full OZ → RD RETIRE
```

## 25. 운영 Runbook

최소 시나리오: - OZ/RD 장애 - 서식/Parameter 오류 - RD/OZ 결과 불일치 -
EDMS/FAX 실패 - 성능 저하 - Cutover/Rollback 실패 - 배포 실패 - Resource
Version 불일치

각 시나리오별로 다음을 정의한다.

``` text
Detection / Impact / Owner / First Action / Check Point
Recovery / Rollback / Escalation / Evidence
```

## 26. 권장 Package Structure

``` text
report-framework/
├── core/
│   ├── ReportRequest
│   ├── ReportResponse
│   ├── ReportContext
│   └── ReportResult
├── routing/
│   ├── ReportRouter
│   ├── RoutingPolicy
│   ├── FeatureToggle
│   └── RollbackPolicy
├── adapter/
│   ├── ReportAdapter
│   ├── RdAdapter
│   └── Oz9Adapter
├── mapping/
│   ├── ReportMapping
│   ├── FormRegistry
│   └── ResourceRegistry
├── parameter/
│   ├── ParameterConverter
│   ├── XmlJsonConverter
│   ├── ParameterValidator
│   └── CanonicalParameter
├── postprocess/
│   ├── PostProcessor
│   ├── EdmsProcessor
│   ├── FaxProcessor
│   ├── MailProcessor
│   └── ImageProcessor
├── reconciliation/
│   ├── ResultComparator
│   ├── DataComparator
│   ├── PdfComparator
│   └── DifferenceReport
├── observability/
│   ├── TraceContext
│   ├── PerformanceTracker
│   ├── ReportLogger
│   └── StatisticsCollector
├── exception/
│   ├── ReportException
│   ├── OzExceptionTranslator
│   └── ErrorCode
├── security/
│   ├── SensitiveDataMasker
│   └── InputValidator
└── configuration/
    ├── TimeoutPolicy
    ├── RetryPolicy
    └── EnvironmentConfig
```

## 27. 개발 Roadmap

### Phase 1 --- Foundation

-   Canonical Request/Response
-   ReportAdapter
-   RD/OZ Adapter
-   ReportRouter
-   Routing Rule

### Phase 2 --- Migration

-   Mapping Registry
-   XML→JSON
-   Parameter Validation
-   Feature Toggle
-   Rollback

### Phase 3 --- Quality

-   RD/OZ Reconciliation
-   Trace
-   Performance
-   Error Standard
-   Security/Masking

### Phase 4 --- Integration

-   EDMS/FAX/MAIL/IMAGE
-   Async Integration
-   Remote Print

### Phase 5 --- Operation

-   Statistics/Monitoring
-   Cutover Dashboard
-   Runbook
-   RD Retirement

## 28. AA 핵심 Top 8

1.  Canonical ReportRequest / ReportResponse
2.  ReportAdapter Interface
3.  RD Adapter / OZ9 Adapter
4.  ReportRouter
5.  Routing Table + Rollback
6.  XML → JSON Parameter Rule
7.  RD/OZ Reconciliation
8.  Request ID + Logging + Performance

## 29. Architecture Definition

> **RD와 OZ를 병행운영하면서 서식·채널·시스템 단위로 안전하게 전환하고,
> 결과 검증·Rollback·성능·보안·후처리·운영 추적을 공통화하는 Report
> Migration & Integration Framework**

단순한 OZ 연동 프로그램이 아니라 향후 다른 Report Engine 교체에도 업무
애플리케이션 변경을 최소화할 수 있는 공통 기반으로 정의한다.

## 30. OZ 측과 추가 확인할 사항

-   OZ 9 실제 Java/JavaScript API 및 SDK
-   OZ Server Failover 설계
-   발행 성공 판정 기준
-   중복 발행 방지 지원 여부
-   발행 상태 조회 가능 여부
-   Client Viewer 책임 범위
-   Server-side 발행 방식
-   OZR/Resource 배포 구조
-   Cache 및 성능 정책
-   Timeout/Retry 권장 정책
-   Remote Print 구조
-   후처리 Interface
-   OZ 자체 Logging/Monitoring 제공 범위

이 항목이 확정되면 `Oz9Adapter`와 공통 운영정책을 최종 확정한다.

import { ReportClient } from "./report-client.js";

const reports = new ReportClient({
  baseUrl: "/api/reports",
  timeoutMs: 30000
});

// Vue3 methods에서도 동일하게 호출 가능
export async function openContractReport(contractNo) {
  try {
    const result = await reports.preview(
      "CONTRACT01",
      { contractNo },
      {
        systemId: "HIPORTAL",
        channelId: "WEB",
        businessId: contractNo
      }
    );

    // B/E가 반환한 URL 또는 Viewer 연계정보를 프로젝트 OZ 규격에 맞춰 사용
    if (result.viewerUrl) {
      window.open(result.viewerUrl, "_blank", "noopener,noreferrer");
    }
    return result;
  } catch (e) {
    console.error("[REPORT]", e.code, e.requestId, e.message);
    alert(e.message);
    throw e;
  }
}

/**
 * RD -> OZ9 병행전환 F/E 공통 Client
 * - Vue3/Vanilla JS 모두 사용 가능
 * - 업무 화면은 RD/OZ를 직접 알지 않고 공통 B/E API만 호출
 * - requestId/idempotencyKey를 이용해 추적/중복요청 통제
 */
export class ReportClient {
  constructor(options = {}) {
    this.baseUrl = options.baseUrl || "/api/reports";
    this.timeoutMs = options.timeoutMs || 30000;
  }

  createRequest(formId, parameters = {}, options = {}) {
    const requestId = options.requestId || this.createRequestId();
    return {
      requestId,
      idempotencyKey: options.idempotencyKey || requestId,
      systemId: options.systemId || "WEB",
      channelId: options.channelId || "WEB",
      businessId: options.businessId || "",
      formId,
      parameters,
      outputType: options.outputType || "VIEW",
      printOption: options.printOption || {},
      postProcess: options.postProcess || []
    };
  }

  async publish(formId, parameters = {}, options = {}) {
    return this.request("/publish", this.createRequest(formId, parameters, options));
  }

  async preview(formId, parameters = {}, options = {}) {
    return this.publish(formId, parameters, { ...options, outputType: "VIEW" });
  }

  async print(formId, parameters = {}, options = {}) {
    return this.publish(formId, parameters, { ...options, outputType: "PRINT" });
  }

  async getStatus(requestId) {
    const response = await fetch(`${this.baseUrl}/${encodeURIComponent(requestId)}/status`, {
      credentials: "same-origin",
      headers: { "Accept": "application/json" }
    });
    return this.parseResponse(response);
  }

  async request(path, body) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await fetch(`${this.baseUrl}${path}`, {
        method: "POST",
        credentials: "same-origin",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "X-Request-Id": body.requestId,
          "X-Idempotency-Key": body.idempotencyKey
          // CSRF를 사용하는 환경이면 프로젝트 표준 Header 추가
        },
        body: JSON.stringify(body),
        signal: controller.signal
      });
      return await this.parseResponse(response);
    } catch (e) {
      if (e.name === "AbortError") {
        // Timeout은 실제 서버 처리 성공 여부가 불명확하므로 무조건 재호출하지 않는다.
        throw new ReportClientError("REPORT-004", "발행 응답시간이 초과되었습니다. 상태 조회 후 재처리하십시오.", body.requestId);
      }
      throw e;
    } finally {
      clearTimeout(timer);
    }
  }

  async parseResponse(response) {
    const contentType = response.headers.get("content-type") || "";
    const data = contentType.includes("application/json")
      ? await response.json()
      : { message: await response.text() };

    if (!response.ok || data.success === false) {
      throw new ReportClientError(
        data.errorCode || `HTTP-${response.status}`,
        data.message || "리포트 처리에 실패했습니다.",
        data.requestId
      );
    }
    return data;
  }

  createRequestId() {
    if (globalThis.crypto?.randomUUID) return crypto.randomUUID();
    return `RPT-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  }
}

export class ReportClientError extends Error {
  constructor(code, message, requestId) {
    super(message);
    this.name = "ReportClientError";
    this.code = code;
    this.requestId = requestId;
  }
}

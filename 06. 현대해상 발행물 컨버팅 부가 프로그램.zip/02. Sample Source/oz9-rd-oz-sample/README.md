# OZ9 RD/OZ 병행전환 샘플 소스

AA 공통 구조를 실제 개발 시작점으로 옮긴 F/E JavaScript + B/E Java 샘플입니다.

## Frontend
- `report-client.js`: 공통 발행 Client
- `report-example.js`: 화면 호출 예제
- F/E는 RD/OZ를 직접 선택하지 않습니다.
- Timeout 발생 시 무조건 Retry하지 않고 requestId로 상태 확인하도록 설계했습니다.

## Backend
- `ReportController` → `ReportService` → `ReportRouter` → `RD/OZ Adapter`
- `ReportRequest`는 솔루션 독립 Canonical Model
- OZ 9 SDK/API는 `Oz9ReportAdapter` 내부에만 넣도록 설계
- Routing 기준은 `SYSTEM_ID + CHANNEL_ID + FORM_ID`
- 현재 RD/OZ 실제 SDK 호출부는 프로젝트 제품 규격이 없으므로 TODO Stub입니다.

## 다음 구현 순서
1. 실제 OZ 9 Java API/Viewer 연동 규격 반영
2. 기존 RD 호출부를 `RdReportAdapter`로 이동
3. Oracle `REPORT_ROUTING`, `REPORT_MAPPING`, 발행이력 테이블 연동
4. XML→JSON Parameter Converter
5. Trace/MDC 및 성능 측정
6. PostProcessor(EDMS/FAX/MAIL)
7. RD/OZ 결과 비교 모듈
8. Idempotency 및 상태조회 정책 확정

## 주의
OZ 9 제품 API 이름을 추측하여 넣지 않았습니다. 공급사 SDK/JAR 및 현재 프로젝트 샘플을 확인한 뒤 `Oz9ReportAdapter`만 구체화하면 됩니다.

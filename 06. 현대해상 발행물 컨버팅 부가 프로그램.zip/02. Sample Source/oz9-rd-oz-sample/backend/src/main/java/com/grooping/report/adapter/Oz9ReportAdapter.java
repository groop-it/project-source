package com.grooping.report.adapter;

import com.grooping.report.model.ReportRequest;
import com.grooping.report.model.ReportResult;
import org.springframework.stereotype.Component;

@Component("OZ")
public class Oz9ReportAdapter implements ReportAdapter {
    @Override
    public ReportResult publish(ReportRequest request) {
        long started = System.currentTimeMillis();

        /*
         * TODO OZ Report 9 공급사 SDK/API 확정 후 이 블록만 교체한다.
         *
         * 1) formId -> 실제 OZR 경로/ID Mapping
         * 2) Canonical parameters -> OZ parameter 변환
         * 3) OZ Server 호출
         * 4) OZ 성공/실패 판정
         * 5) Viewer URL 또는 발행 결과 생성
         *
         * 중요: OZ SDK 클래스가 다른 업무 계층으로 새어나가지 않도록 한다.
         */
        String viewerUrl = "/oz/viewer?requestId=" + request.getRequestId();

        return ReportResult.success(
            request.getRequestId(), "OZ", viewerUrl,
            System.currentTimeMillis() - started
        );
    }
}

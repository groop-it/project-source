package com.grooping.report.web;

import com.grooping.report.model.ReportRequest;
import com.grooping.report.model.ReportResult;
import com.grooping.report.service.ReportService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/reports")
public class ReportController {
    private final ReportService service;

    public ReportController(ReportService service) {
        this.service = service;
    }

    @PostMapping("/publish")
    public ResponseEntity<ReportResult> publish(@RequestBody ReportRequest request) {
        return ResponseEntity.ok(service.publish(request));
    }

    @GetMapping("/{requestId}/status")
    public ResponseEntity<?> status(@PathVariable String requestId) {
        // TODO 실제 발행이력/상태 저장소 조회
        return ResponseEntity.ok(java.util.Map.of(
            "success", true,
            "requestId", requestId,
            "status", "UNKNOWN"
        ));
    }
}

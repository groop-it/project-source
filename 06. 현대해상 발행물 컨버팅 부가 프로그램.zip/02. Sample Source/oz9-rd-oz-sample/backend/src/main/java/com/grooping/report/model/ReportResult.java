package com.grooping.report.model;

public class ReportResult {
    private boolean success;
    private String requestId;
    private String engine;
    private String viewerUrl;
    private String errorCode;
    private String message;
    private long elapsedMs;

    public static ReportResult success(String requestId, String engine, String viewerUrl, long elapsedMs) {
        ReportResult r = new ReportResult();
        r.success = true; r.requestId = requestId; r.engine = engine;
        r.viewerUrl = viewerUrl; r.elapsedMs = elapsedMs;
        return r;
    }

    public boolean isSuccess() { return success; }
    public void setSuccess(boolean v) { success = v; }
    public String getRequestId() { return requestId; }
    public void setRequestId(String v) { requestId = v; }
    public String getEngine() { return engine; }
    public void setEngine(String v) { engine = v; }
    public String getViewerUrl() { return viewerUrl; }
    public void setViewerUrl(String v) { viewerUrl = v; }
    public String getErrorCode() { return errorCode; }
    public void setErrorCode(String v) { errorCode = v; }
    public String getMessage() { return message; }
    public void setMessage(String v) { message = v; }
    public long getElapsedMs() { return elapsedMs; }
    public void setElapsedMs(long v) { elapsedMs = v; }
}

package com.grooping.report.routing;

import com.grooping.report.model.ReportRequest;
import org.springframework.stereotype.Component;

@Component
public class ReportRouter {

    public String selectEngine(ReportRequest request) {
        /*
         * TODO 운영에서는 REPORT_ROUTING 테이블/기존 설정 저장소 조회.
         * Key 권장: SYSTEM_ID + CHANNEL_ID + FORM_ID
         *
         * 조회 실패 시 기본 RD 유지 여부는 고객사 승인 정책으로 확정.
         */
        if ("HIPORTAL".equals(request.getSystemId())
                && "CONTRACT01".equals(request.getFormId())) {
            return "OZ";
        }
        return "RD";
    }
}

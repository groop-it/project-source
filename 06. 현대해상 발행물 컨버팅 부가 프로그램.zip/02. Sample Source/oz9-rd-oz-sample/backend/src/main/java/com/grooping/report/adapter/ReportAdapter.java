package com.grooping.report.adapter;

import com.grooping.report.model.ReportRequest;
import com.grooping.report.model.ReportResult;

public interface ReportAdapter {
    ReportResult publish(ReportRequest request);
}

package com.grooping.report.adapter;

import com.grooping.report.model.ReportRequest;
import com.grooping.report.model.ReportResult;
import org.springframework.stereotype.Component;

@Component("RD")
public class RdReportAdapter implements ReportAdapter {
    @Override
    public ReportResult publish(ReportRequest request) {
        long started = System.currentTimeMillis();

        // TODO 기존 RD 공통 호출 모듈을 이 위치에서 호출.
        // 업무 Controller/Service에는 RD 전용 코드를 남기지 않는다.
        String viewerUrl = "/rd/viewer?requestId=" + request.getRequestId();

        return ReportResult.success(
            request.getRequestId(), "RD", viewerUrl,
            System.currentTimeMillis() - started
        );
    }
}

package com.grooping.report.model;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class ReportRequest {
    private String requestId;
    private String idempotencyKey;
    private String systemId;
    private String channelId;
    private String businessId;
    private String formId;
    private Map<String, Object> parameters = Collections.emptyMap();
    private String outputType = "VIEW";
    private Map<String, Object> printOption = Collections.emptyMap();
    private List<String> postProcess = Collections.emptyList();

    public String getRequestId() { return requestId; }
    public void setRequestId(String v) { requestId = v; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public void setIdempotencyKey(String v) { idempotencyKey = v; }
    public String getSystemId() { return systemId; }
    public void setSystemId(String v) { systemId = v; }
    public String getChannelId() { return channelId; }
    public void setChannelId(String v) { channelId = v; }
    public String getBusinessId() { return businessId; }
    public void setBusinessId(String v) { businessId = v; }
    public String getFormId() { return formId; }
    public void setFormId(String v) { formId = v; }
    public Map<String, Object> getParameters() { return parameters; }
    public void setParameters(Map<String, Object> v) { parameters = v; }
    public String getOutputType() { return outputType; }
    public void setOutputType(String v) { outputType = v; }
    public Map<String, Object> getPrintOption() { return printOption; }
    public void setPrintOption(Map<String, Object> v) { printOption = v; }
    public List<String> getPostProcess() { return postProcess; }
    public void setPostProcess(List<String> v) { postProcess = v; }
}

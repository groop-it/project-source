package com.grooping.report.service;

import com.grooping.report.adapter.ReportAdapter;
import com.grooping.report.model.ReportRequest;
import com.grooping.report.model.ReportResult;
import com.grooping.report.routing.ReportRouter;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;

@Service
public class ReportService {
    private final ReportRouter router;
    private final Map<String, ReportAdapter> adapters;

    public ReportService(ReportRouter router, Map<String, ReportAdapter> adapters) {
        this.router = router;
        this.adapters = adapters;
    }

    public ReportResult publish(ReportRequest request) {
        validate(request);

        if (isBlank(request.getRequestId())) {
            request.setRequestId(UUID.randomUUID().toString());
        }

        String engine = router.selectEngine(request);
        ReportAdapter adapter = adapters.get(engine);
        if (adapter == null) {
            throw new IllegalStateException("REPORT-007: 지원하지 않는 Report Engine: " + engine);
        }

        // TODO MDC에 requestId 설정하여 전 구간 Trace
        // TODO Idempotency 저장/조회 정책 적용
        // TODO 성능 구간 측정
        // TODO PostProcessor 연계
        return adapter.publish(request);
    }

    private void validate(ReportRequest r) {
        if (r == null || isBlank(r.getFormId())) {
            throw new IllegalArgumentException("REPORT-002: formId는 필수입니다.");
        }
        if (isBlank(r.getSystemId()) || isBlank(r.getChannelId())) {
            throw new IllegalArgumentException("REPORT-002: systemId/channelId는 필수입니다.");
        }
    }

    private boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }
}

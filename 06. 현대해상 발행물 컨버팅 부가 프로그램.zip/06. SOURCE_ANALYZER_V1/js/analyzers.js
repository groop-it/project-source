const Analyzer=(()=>{
const map={".java":"Java",".js":"JavaScript",".ts":"TypeScript",".jsp":"JSP",".html":"HTML",".htm":"HTML",".vue":"Vue",".xml":"XML",".sql":"SQL",".properties":"Properties",".json":"JSON",".css":"CSS"};
const ext=p=>(p.toLowerCase().match(/(\.[^.\/]+)$/)||["",""])[1], lang=p=>map[ext(p)]||"Text", ln=(s,i)=>s.slice(0,i).split("\n").length;
function scan(s,re,fn){let a=[],m;re.lastIndex=0;while((m=re.exec(s))){a.push(fn(m,ln(s,m.index)));if(!m[0])re.lastIndex++}return a}
function comments(s,l){let a=[],add=(re,t)=>a.push(...scan(s,re,(m,n)=>({line:n,type:t,text:(m[1]||m[0]).trim()})));
if(["Java","JavaScript","TypeScript","JSP","Vue","CSS"].includes(l)){add(/\/\*([\s\S]*?)\*\//g,"BLOCK");add(/\/\/([^\n\r]*)/g,"LINE")}
if(["HTML","XML","Vue","JSP"].includes(l))add(/<!--([\s\S]*?)-->/g,"HTML");if(l==="SQL")add(/--([^\n\r]*)/g,"SQL");if(l==="Properties")add(/^[#!]([^\n\r]*)/gm,"PROPERTY");
a.sort((x,y)=>x.line-y.line);a.forEach(c=>{let t=c.text.toUpperCase();c.category=t.includes("TODO")?"TODO":t.includes("FIXME")?"FIXME":t.includes("DEPRECATED")?"DEPRECATED":/(20\d\d|수정|변경|CHANGE)/i.test(c.text)?"CHANGE_HISTORY":/(장애|예외|ERROR|FAIL|비상)/i.test(c.text)?"EXCEPTION_NOTE":"GENERAL"});return a}
function analyze(path,s){let l=lang(path),classes=[],imports=[],vars=[],methods=[],exceptions=[],calls=[],db=[],api=[],risks=[],flow=[];
if(l==="Java"){imports=scan(s,/^\s*import\s+([\w.*]+)\s*;/gm,(m,n)=>[n,m[1]]);classes=scan(s,/\b(class|interface|enum)\s+(\w+)/g,(m,n)=>[n,m[1],m[2]]);
methods=scan(s,/(?:public|protected|private|static|final|synchronized|\s)+\s*([\w<>\[\], ?]+)\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w., ]+)?\s*\{/g,(m,n)=>[n,m[1].trim(),m[2],m[3].trim()]);
vars=scan(s,/\b(?:final\s+)?(String|int|long|double|float|boolean|Integer|Long|BigDecimal|Date|LocalDate|LocalDateTime|List<[^>]+>|Map<[^>]+>|Set<[^>]+>|[\w]+DTO|[\w]+VO)\s+(\w+)\s*(?:=([^;]+))?;/g,(m,n)=>[n,m[1],m[2],(m[3]||"").trim()]);}
else if(["JavaScript","TypeScript","Vue","JSP","HTML"].includes(l)){vars=scan(s,/\b(const|let|var)\s+([A-Za-z_$][\w$]*)\s*(?:=([^;\n]+))?/g,(m,n)=>[n,m[1],m[2],(m[3]||"").trim()]);
methods=scan(s,/\b(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(([^)]*)\)/g,(m,n)=>[n,"",m[1],m[2]]);}
exceptions=scan(s,/\b(try|catch\s*\(([^)]*)\)|finally|throw\s+new\s+(\w+))/g,(m,n)=>[n,m[0]]);
calls=scan(s,/\b([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*\(/g,(m,n)=>[n,m[1]]).filter(x=>!["if","for","while","switch","catch","function"].includes(x[1]));
db=scan(s,/\b(SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM|MERGE\s+INTO|CREATE\s+TABLE|ALTER\s+TABLE)\b/gi,(m,n)=>[n,m[1].toUpperCase(),s.split(/\r?\n/)[n-1].trim()]);
db.push(...scan(s,/\b(\w*(?:Mapper|DAO|Repository))\.(\w+)\s*\(/g,(m,n)=>[n,"DB_CALL",m[0]]));
api=scan(s,/\b(fetch|axios\.(?:get|post|put|delete)|XMLHttpRequest|RestTemplate|WebClient|HttpClient|EAI|OZ|RD)\b/gi,(m,n)=>[n,m[1],s.split(/\r?\n/)[n-1].trim()]);
s.split(/\r?\n/).forEach((x,i)=>{let t=x.trim();if(/\bif\s*\(/.test(t))flow.push([i+1,"IF",t]);else if(/\belse\b/.test(t))flow.push([i+1,"ELSE",t]);else if(/\b(for|while)\s*\(/.test(t))flow.push([i+1,"LOOP",t]);else if(/\bswitch\s*\(/.test(t))flow.push([i+1,"SWITCH",t]);else if(/\breturn\b/.test(t))flow.push([i+1,"RETURN",t]);else if(/\b(throw|catch|finally)\b/.test(t))flow.push([i+1,"EXCEPTION",t])});
if(/\bcatch\s*\([^)]*\)\s*\{\s*\}/s.test(s))risks.push(["HIGH","빈 catch 블록 존재"]);if(/\bcatch\s*\(\s*Exception\b/.test(s))risks.push(["MEDIUM","광범위한 catch(Exception) 사용"]);if(/password\s*=\s*["'][^"']+["']/i.test(s))risks.push(["HIGH","하드코딩 비밀번호 가능성"]);if(/\bSystem\.out\.print/.test(s))risks.push(["LOW","System.out 운영 로깅 정책 확인"]);if(/\b(TODO|FIXME)\b/i.test(s))risks.push(["LOW","TODO/FIXME 존재"]);if(/\b(RD|\.mrd)\b/i.test(s)&&/\b(OZ|\.ozr)\b/i.test(s))risks.push(["MEDIUM","RD/OZ 병행 코드 존재"]);
let cm=comments(s,l);return {path,lang:l,lines:s.split(/\r?\n/).length,source:s,classes,imports,vars,methods,exceptions,calls,db,api,risks,flow,comments:cm,summary:{methods:methods.length,variables:vars.length,exceptions:exceptions.length,comments:cm.length,todos:cm.filter(x=>["TODO","FIXME"].includes(x.category)).length,db:db.length,api:api.length,risks:risks.length}}}
return {analyze,map};})();
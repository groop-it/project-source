SOURCE ANALYZER V1
1) 압축 해제
2) index.html 실행 (Chrome/Edge 권장)
3) 파일 또는 프로젝트 폴더 선택 후 분석

지원: java, js, ts, jsp, html, vue, xml, sql, properties, json, css
분석: 클래스/import, 변수, 메소드, 호출, 로직 flow, 예외, 주석/TODO/FIXME/변경이력, DB/SQL, API/RD/OZ, 위험 규칙, JSON/CSV 출력

V1은 외부 Parser 없는 규칙 기반 정적 분석기입니다. AST/컴파일러 수준 의미 분석은 후속 버전에서 확장합니다.

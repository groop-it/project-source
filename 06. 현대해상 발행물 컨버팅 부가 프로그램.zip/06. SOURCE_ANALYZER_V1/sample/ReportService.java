package sample.report;
public class ReportService {
 private String engine="OZ";
 // TODO: RD 병행운영 종료 후 제거
 public void print(String contractNo){
  if(contractNo==null) throw new IllegalArgumentException("contractNo");
  try { callOZ("contract.ozr"); } catch(Exception e){ System.out.println(e); }
 }
 private void callOZ(String name){ System.out.println("OZ:"+name); }
}

// TODO OZ 공통 호출
async function printReport(contractNo){
 if(!contractNo) return;
 try { return await fetch("/api/report/oz"); } catch(e){ console.error(e); throw e; }
}

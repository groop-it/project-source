OZ Parameter Reference V1.1 FIXED

수정사항
- Grid CSS 구조를 제거하고 표준 HTML table 구조로 변경
- Header와 첫 데이터 행이 겹치던 문제 수정
- Sticky header 제거
- Column width를 colgroup으로 고정
- Row 클릭 Toggle 상세 유지
- 검색 / Category Filter / Example Copy 유지
- 외부 CDN 없음

데이터
- 기존 V1의 OZ Parameter 1,029건 그대로 사용

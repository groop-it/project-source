# OZ Developer Reference V2

업무단 개발자가 OZ 공식 매뉴얼을 직접 뒤지지 않고,
- Viewer Parameter
- OZ Java Server Method
- 서버 Form/ODI Parameter 전달
- Scheduler API / Parameter
를 빠르게 검색하기 위한 Offline HTML Reference입니다.

## 구성
- index.html
- oz-viewer-parameter-reference.html
- oz-server-api-reference.html
- oz-server-parameter-reference.html
- oz-scheduler-api-reference.html
- oz-developer-guide.html

## 주의
별표(사용빈도)는 FORCS 공식 통계가 아니라 업무개발 탐색 우선순위를 위한 프로젝트 참고값입니다.
현대해상 실제 Wrapper/공통모듈/환경값은 프로젝트 소스를 기준으로 확인해야 합니다.

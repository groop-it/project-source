# OZ Report + WebSquare F/E Sample Package

첨부 `ozviewer_Guide.pdf`의 OZ HTML5JS 실행 방식과 WebSquare의 XML/scwin lifecycle을 결합한 샘플입니다.

## 기본 구조
1. WebSquare 화면 `scwin.onpageload`
2. OZ 전역 callback bridge 설치
3. `SetOZParamters_OZViewer`에서 `sendToActionScript`
4. `start_ozjs("OZViewer", "/ozrviewer/")`
5. `OZUserActionCommand_OZViewer(type, attr)` → `scwin.oz.onUserAction`

## 주의
- 실제 프로젝트의 WebSquare 버전/공통 프레임에 따라 화면 종료 hook 또는 외부 JS 로딩 방식이 다를 수 있습니다.
- OZ Vendor JS/CSS는 이 ZIP에 포함하지 않습니다. 실제 서버의 `/ozrviewer/` 리소스를 사용하세요.
- `connection.servlet`, `connection.reportname`을 실제 환경 값으로 변경하세요.

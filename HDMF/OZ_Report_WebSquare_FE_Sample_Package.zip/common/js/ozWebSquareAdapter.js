(function(global) {
    "use strict";

    function getViewer(viewerId) {
        var el = document.getElementById(viewerId);
        if (!el) {
            throw new Error("OZ Viewer DOM not found: " + viewerId);
        }
        return el;
    }

    function normalizeValue(value) {
        if (value === null || value === undefined) return "";
        if (typeof value === "object") return JSON.stringify(value);
        return String(value);
    }

    var OZWS = {
        setParam: function(viewerId, key, value) {
            var viewer = getViewer(viewerId);
            viewer.sendToActionScript(key, normalizeValue(value));
        },

        setParams: function(viewerId, params) {
            Object.keys(params || {}).forEach(function(key) {
                OZWS.setParam(viewerId, key, params[key]);
            });
        },

        start: function(viewerId, viewerPath, options) {
            if (typeof global.start_ozjs !== "function") {
                throw new Error("start_ozjs is not loaded. Check OZ Viewer vendor resources.");
            }
            if (options) {
                global.start_ozjs(viewerId, viewerPath, options);
            } else {
                global.start_ozjs(viewerId, viewerPath);
            }
        },

        parseAttr: function(attr) {
            if (!attr) return {};
            try { return JSON.parse(attr); }
            catch (e) {
                console.warn("[OZ] attr JSON parse failed:", attr);
                return {};
            }
        },

        installUserActionBridge: function(viewerId, handler) {
            global["OZUserActionCommand_" + viewerId] = function(type, attr) {
                handler(type, OZWS.parseAttr(attr), attr);
            };
        },

        removeUserActionBridge: function(viewerId) {
            try { delete global["OZUserActionCommand_" + viewerId]; } catch (e) {}
        }
    };

    global.OZWS = OZWS;
})(window);

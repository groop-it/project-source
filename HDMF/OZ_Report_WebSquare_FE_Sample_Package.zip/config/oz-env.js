window.OZ_ENV = {
    DEV: {
        viewerPath: "/ozrviewer/",
        servlet: "http://DEV_HOST:PORT/prj_name/server"
    },
    TEST: {
        viewerPath: "/ozrviewer/",
        servlet: "http://TEST_HOST:PORT/prj_name/server"
    },
    PROD: {
        viewerPath: "/ozrviewer/",
        servlet: "http://PROD_HOST:PORT/prj_name/server"
    }
};

# WebSquare + OZ Integration Checklist

## 최초 연결
- [ ] WebSquare 화면 `scwin.onpageload` 정상 호출
- [ ] OZ Vendor 리소스 `/ozrviewer/` HTTP 200
- [ ] `#OZViewer` 높이/너비 확보
- [ ] `window.SetOZParamters_OZViewer` 설치
- [ ] `connection.servlet` 실제 OZ Server URL
- [ ] `connection.reportname` 실제 Repository 경로
- [ ] `start_ozjs()` 1회 실행

## 업무 파라미터
- [ ] pcount와 args# 개수 일치
- [ ] null/blank 정책 확인
- [ ] 날짜/숫자 포맷 확인
- [ ] ODI별 args# 사용 시 ODI name 확인

## 이벤트
- [ ] Binding 완료 추적
- [ ] Error/Print/Export/Progress 활성화 파라미터 확인
- [ ] WebSquare 화면 재진입 시 global callback 중복 확인

## 운영
- [ ] DEV/TEST/PROD OZ 주소 분리
- [ ] Browser Console / Network / OZ Server log 확인 절차 공유

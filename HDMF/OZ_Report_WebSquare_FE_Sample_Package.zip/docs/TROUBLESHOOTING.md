# WebSquare + OZ Troubleshooting

## Viewer 자체가 안 뜰 때
1. `/ozrviewer/` 리소스 404 여부
2. `start_ozjs` 전역 함수 존재 여부
3. `OZViewer` div 높이 0 여부
4. `SetOZParamters_OZViewer` 함수명과 Viewer ID 일치 여부

## Viewer는 뜨지만 보고서가 안 뜰 때
1. `connection.servlet`
2. `connection.reportname`
3. OZ Repository 파일 존재
4. Network 요청/응답
5. OZ Server 로그

## 느릴 때
- `viewer.progresscommand=true`
- step 3: 데이터 다운로드
- step 4: 보고서 바인딩
으로 구간을 분리합니다.

## 인쇄/저장
- `print_exportfrom`: viewer / server / scheduler
- `save_exportfrom`: PDF server / scheduler
- OZ Print/Export 결과 이벤트 확인
